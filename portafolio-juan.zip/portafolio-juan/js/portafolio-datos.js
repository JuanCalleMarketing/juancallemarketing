/*
  ============================================================
  AQUÍ ADMINISTRAS TU PORTAFOLIO
  ============================================================
  Cada trabajo es un bloque entre llaves { ... } separado por comas.
  Para agregar uno nuevo, copia un bloque completo, pégalo debajo y cambia los datos.
  Para quitar uno, borra el bloque completo.

  CAMPOS
  tipo         "video" para videos y reels, "pieza" para piezas gráficas.
  marca        Nombre de la marca. Los filtros se arman solos con estos nombres.
  titulo       Nombre corto del trabajo.
  descripcion  Una o dos frases (opcional).
  formato      Forma de la vista previa: "vertical" (9:16), "retrato" (4:5),
               "cuadrado" (1:1) o "horizontal" (16:9).
  destacado    true si quieres que aparezca en la parte de arriba de la página
               (usa true en 3 trabajos).
  colores      Dos colores que se ven mientras falta el archivo (opcional).

  PARA VIDEOS (elige una de las dos opciones)
  archivo      Ruta del video dentro del proyecto. Ej: "assets/videos/zenkon-reel.mp4"
  youtube      Código del video de YouTube (lo que va después de v= en el enlace).
  portada      Imagen de portada del video (opcional). Ej: "assets/posters/zenkon-reel.jpg"

  PARA PIEZAS GRÁFICAS
  archivos     Lista de imágenes. Con una sola se ve la imagen; con varias, un carrusel.
               Ej: ["assets/piezas/zenkon-1.jpg", "assets/piezas/zenkon-2.jpg"]

  Mientras un archivo no exista en la carpeta, verás un cuadro de color con la
  etiqueta "Ejemplo". Cuando subas el archivo real, la etiqueta desaparece sola.
*/

window.PORTAFOLIO = [
  {
    tipo: "video",
    marca: "ZenKon",
    titulo: "Reel de presentación",
    descripcion: "Video corto para mostrar el acabado en microconcreto.",
    formato: "vertical",
    archivo: "assets/videos/zenkon-reel-01.mp4",
    portada: "assets/posters/zenkon-reel-01.jpg",
    destacado: true,
    colores: ["#2342F0", "#0F1218"]
  },
  {
    tipo: "pieza",
    marca: "ZenKon",
    titulo: "Línea de acabados",
    descripcion: "Serie de piezas para redes.",
    formato: "cuadrado",
    archivos: ["assets/piezas/zenkon-01.jpg", "assets/piezas/zenkon-02.jpg"],
    destacado: true,
    colores: ["#5B6472", "#0F1218"]
  },
  {
    tipo: "video",
    marca: "Enchilaitos",
    titulo: "Anuncio de gomitas enchiladas",
    descripcion: "Video pensado para pauta en Meta Ads.",
    formato: "vertical",
    archivo: "assets/videos/enchilaitos-anuncio-01.mp4",
    portada: "assets/posters/enchilaitos-anuncio-01.jpg",
    destacado: true,
    colores: ["#D6342C", "#0F1218"]
  },
  {
    tipo: "pieza",
    marca: "Capolusso",
    titulo: "Colección de hoodies",
    descripcion: "Pieza para lanzamiento de colección.",
    formato: "retrato",
    archivos: ["assets/piezas/capolusso-01.jpg"],
    colores: ["#1B1F2A", "#6B4EFF"]
  },
  {
    tipo: "video",
    marca: "Vamos Travel",
    titulo: "Destino del mes",
    descripcion: "Reel de destino para redes.",
    formato: "vertical",
    archivo: "assets/videos/vamos-travel-destino-01.mp4",
    colores: ["#0E7C86", "#0F1218"]
  },
  {
    tipo: "pieza",
    marca: "Legal Pets",
    titulo: "Contenido informativo",
    descripcion: "Pieza educativa para dueños de mascotas.",
    formato: "cuadrado",
    archivos: ["assets/piezas/legal-pets-01.jpg"],
    colores: ["#2F7D5B", "#0F1218"]
  },
  {
    tipo: "video",
    marca: "La Vete",
    titulo: "Presentación de la clínica",
    descripcion: "Video horizontal de presentación.",
    formato: "horizontal",
    archivo: "assets/videos/la-vete-clinica-01.mp4",
    colores: ["#3B82F6", "#0F1218"]
  },
  {
    tipo: "pieza",
    marca: "Sergio Abogado",
    titulo: "Derecho médico",
    descripcion: "Pieza para posicionar la especialidad.",
    formato: "retrato",
    archivos: ["assets/piezas/sergio-abogado-01.jpg"],
    colores: ["#2A3244", "#2342F0"]
  },
  {
    tipo: "pieza",
    marca: "Inmobiliaria DP",
    titulo: "Proyecto exclusivo",
    descripcion: "Pieza para captar interesados.",
    formato: "cuadrado",
    archivos: ["assets/piezas/inmobiliaria-dp-01.jpg"],
    colores: ["#8A6A2F", "#0F1218"]
  }
];
