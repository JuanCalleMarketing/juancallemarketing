# Juan Calle Marketing: página y portafolio

Esta carpeta es tu página completa. No necesita instalar nada: es una página estática que se publica tal cual en Vercel.

## Qué hay en la carpeta

- `index.html`: el contenido de la página (textos, secciones).
- `css/styles.css`: colores, tipografías y diseño.
- `js/portafolio-datos.js`: la lista de tus videos y piezas gráficas. Es el único archivo que vas a editar con frecuencia.
- `js/main.js`: el funcionamiento (filtros, visor, menú). No hace falta tocarlo.
- `assets/videos`, `assets/piezas`, `assets/posters`: aquí van tus archivos.

## 1. Agregar tus videos y piezas gráficas

1. Copia tus archivos a la carpeta correspondiente:
   - Videos en `assets/videos/`
   - Imágenes de piezas gráficas en `assets/piezas/`
   - Portadas de video (opcional) en `assets/posters/`
2. Abre `js/portafolio-datos.js` y, por cada trabajo, edita un bloque o copia uno nuevo. Dentro del archivo hay una explicación de cada campo.
3. Guarda y abre `index.html` con doble clic para verlo en tu computador antes de publicar.

Mientras un archivo no exista, esa tarjeta muestra un cuadro de color con la etiqueta "Ejemplo". Al subir el archivo real, la etiqueta desaparece sola.

### Recomendaciones para que la página cargue rápido

- **Videos:** formato MP4, de preferencia vertical 720 x 1280, de 15 a 40 segundos y menos de 10 MB cada uno. Puedes comprimirlos gratis con HandBrake o con la opción de exportar de CapCut.
- **Piezas gráficas:** formato JPG o WebP, de unos 1080 píxeles de ancho y menos de 400 KB cada una.
- **Videos largos o pesados:** súbelos a YouTube como "No listado" y en el bloque usa `youtube: "CODIGO"` en lugar de `archivo`. El código es lo que aparece después de `v=` en el enlace.
- **Nombres de archivo:** en minúsculas, sin tildes ni espacios (por ejemplo `zenkon-reel-01.mp4`).
- GitHub no permite subir desde el navegador archivos de más de 25 MB.

## 2. Subir el proyecto a GitHub

### Opción fácil (desde el navegador, sin instalar nada)

1. Entra a github.com e inicia sesión.
2. Toca el botón **New** para crear un repositorio. Nómbralo, por ejemplo, `juancallemarketing`. Déjalo en **Public** o **Private** (ambas funcionan con Vercel) y crea el repositorio.
3. En la página del repositorio vacío toca **uploading an existing file**.
4. Abre la carpeta del proyecto en tu computador, selecciona **todo su contenido** (no la carpeta en sí) y arrástralo a la ventana de GitHub. Así se conservan las subcarpetas.
5. Abajo toca **Commit changes**.

Comprueba que en GitHub veas `index.html`, `css`, `js` y `assets` en la primera pantalla del repositorio. Si ves una sola carpeta que los contiene, súbelos de nuevo sin esa carpeta contenedora.

### Opción con GitHub Desktop (recomendada si vas a actualizar seguido)

1. Instala GitHub Desktop (desktop.github.com) e inicia sesión.
2. Menú **File → Add local repository** y elige la carpeta del proyecto. Si te dice que no es un repositorio, toca **create a repository**.
3. Escribe un título corto del cambio y toca **Commit to main**.
4. Toca **Publish repository** y confirma.

Para futuras actualizaciones: cambias archivos, abres GitHub Desktop, escribes el título del cambio, **Commit** y **Push origin**.

## 3. Publicarlo en Vercel

Como ya tienes `juancallemarketing.vercel.app`, lo ideal es conservar esa misma dirección.

### Si quieres conservar la dirección actual

1. Entra a vercel.com y abre el proyecto `juancallemarketing`.
2. Ve a **Settings → Git** y toca **Connect Git Repository**.
3. Elige el repositorio que creaste en GitHub.
4. Ve a **Deployments** y lanza un nuevo despliegue (**Redeploy**) o haz un pequeño cambio en GitHub para que se publique solo.

Si esa opción no aparece, porque el proyecto actual se subió de otra forma, usa el camino siguiente.

### Si prefieres crear un proyecto nuevo

1. En Vercel toca **Add New → Project**.
2. Elige tu repositorio y toca **Import**.
3. En **Framework Preset** deja **Other**. No cambies nada más.
4. Toca **Deploy**. En menos de un minuto tendrás una dirección nueva.
5. Para recuperar el nombre `juancallemarketing`, primero cambia el nombre o elimina el proyecto anterior, y luego en el proyecto nuevo ve a **Settings → General → Project Name** y ponle `juancallemarketing`. Si el nombre ya estuviera ocupado, Vercel te lo indicará.

### Después de publicar

Cada vez que subas un cambio a GitHub, Vercel publica la nueva versión solo, en aproximadamente un minuto. Para agregar un video nuevo: súbelo a `assets/videos`, agrega su bloque en `js/portafolio-datos.js` y confirma el cambio.

También puedes editar un archivo directamente en GitHub: ábrelo, toca el lápiz, cambia el texto y toca **Commit changes**.

## Cambios respecto a tu página anterior

- Se agregó la sección **Portafolio** justo después del inicio, con filtros por tipo y por marca, y un visor para ver cada video o pieza en grande.
- El formulario de contacto ahora abre WhatsApp con el mensaje ya escrito, así no depende de ningún servicio externo.
- Se quitó el boletín del pie de página y los enlaces de Políticas y Términos que no llevaban a ninguna parte. Si los necesitas, avísame y los armamos bien.
- El enlace a tu portafolio de Behance se mantiene al final de la sección Portafolio.
